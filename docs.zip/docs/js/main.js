$(function(){

//start mobil menu open-close
$('.menu__btn').click(function(){
	$(this).toggleClass('active');
	$('.menu').toggleClass('active');
})
//end mobil-menu open-close
});